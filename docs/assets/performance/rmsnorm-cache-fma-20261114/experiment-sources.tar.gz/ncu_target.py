"""Warm up and expose one representative kernel to Nsight Compute."""
import argparse
from pathlib import Path
from gpu_guard import Guard, UUID

p = argparse.ArgumentParser()
p.add_argument('arm',choices=('fixed','fma'))
p.add_argument('width',type=int)
p.add_argument('rows',type=int)
a = p.parse_args()
guard = Guard(f'ncu-{a.arm}-{a.width}-{a.rows}')
import torch
here = Path(__file__).resolve().parent
torch.ops.load_library(str((here/f'build-rms_cache_{a.arm}/rms_cache_{a.arm}.so').resolve()))
torch.set_num_threads(1)
torch.manual_seed(2912)
assert str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-') == UUID.removeprefix('GPU-')
with torch.inference_mode():
    x = torch.randn(a.rows,a.width,dtype=torch.float32,device='cuda')
    w = torch.randn(a.width,device='cuda')
    out = torch.empty_like(x)
    op = getattr(torch.ops,f'rms_cache_{a.arm}').run_out
    for _ in range(10):
        op(out,x,w,1e-6,None)
    torch.cuda.synchronize()
    op(out,x,w,1e-6,None)
    torch.cuda.synchronize()
guard.finish()
print('complete',a,flush=True)

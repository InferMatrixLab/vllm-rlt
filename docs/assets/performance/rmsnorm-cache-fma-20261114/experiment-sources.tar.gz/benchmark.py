"""Source-derived four-arm, same-output CUDA-graph benchmark and accuracy gate."""
import argparse
import hashlib
import json
import os
import random
import statistics
import subprocess
import time
from pathlib import Path
from gpu_guard import Guard, UUID

parser = argparse.ArgumentParser()
parser.add_argument('phase', choices=('key', 'matrix', 'extended'))
args = parser.parse_args()
guard = Guard(args.phase)
import torch
from vllm_rlt.kernels.normalization import rms_norm, rms_norm_reference

here = Path(__file__).resolve().parent
for name in ('old', 'fixed', 'fma'):
    torch.ops.load_library(str((here/f'build-rms_cache_{name}/rms_cache_{name}.so').resolve()))
vllm = Path('artifacts/rmsnorm-generic-20261109/vllm-source-build/build/vllm_rms_review.so')
torch.ops.load_library(str(vllm.resolve()))
torch.set_num_threads(1)
tol = {'float32':2e-6, 'float16':2e-3, 'bfloat16':1e-2}
torch.manual_seed(3039 if args.phase == 'extended' else 42)
rng = random.Random(8943)

def hashfile(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()

def groups():
    if args.phase == 'extended':
        # Original policy experiment generated a fresh residual only when requested.
        for dtype_name,h,rows,add in json.loads(Path('artifacts/rmsnorm-policy-20261110/contract.json').read_text())['cases']:
            yield dtype_name,h,rows,[add]
        return
    dtypes = ('bfloat16','float16','float32')
    if args.phase == 'key':
        shapes = [(2049,1),(2049,8),(2049,128),(4096,1024),(8192,4),
                  (4097,4),(4097,1024),(8193,4),(8193,1024)]
        for dtype in dtypes:
            for h,rows in shapes:
                yield dtype,h,rows,[False,True]
    else:
        for dtype in dtypes:
            for h in (128,256,768,2048,2049,4096,8192):
                for rows in (1,2,4,8,16,32,64,128,256,1024):
                    yield dtype,h,rows,[False,True]
        for dtype in dtypes:
            for h in (4097,8193):
                for rows in (4,1024):
                    yield dtype,h,rows,[False,True]

def accuracy(actual, ref, native, precision):
    delta = (actual.float() - ref.float()).abs()
    bad = ~torch.isclose(actual, ref, atol=precision, rtol=precision, equal_nan=True)
    count = int(bad.sum().item())
    entry = {'max_abs_vs_reference':float(delta.max().item()),
             'mismatched_elements':count, 'assert_close_passed':count == 0,
             'unequal_fraction_vs_production_fixed':float((actual != native).float().mean().item())}
    if count:
        indices = bad.nonzero()[:5].tolist()
        entry['examples'] = [{'index':i,'actual':float(actual[tuple(i)].item()),
                              'reference':float(ref[tuple(i)].item()),
                              'production_fixed':float(native[tuple(i)].item())} for i in indices]
    return entry

prop = torch.cuda.get_device_properties(0)
if str(prop.uuid).removeprefix('GPU-') != UUID.removeprefix('GPU-'):
    raise RuntimeError(f'Visible GPU UUID is {prop.uuid}, expected {UUID}')
metadata = {'phase':args.phase, 'time_unix':time.time(), 'git_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),
            'gpu':prop.name,'gpu_uuid':str(prop.uuid),'sm_count':prop.multi_processor_count,
            'torch':torch.__version__,'torch_cuda':torch.version.cuda,'seed':3039 if args.phase=='extended' else 42,
            'tolerances':tol, 'warmup':10, 'repeats':7, 'iterations':50, 'graph_unroll':32,
            'contract_sha256':hashfile(here/'CONTRACT.md'), 'vllm_sha256':hashfile(vllm),
            'library_sha256':{name:hashfile(here/f'build-rms_cache_{name}/rms_cache_{name}.so') for name in ('old','fixed','fma')},
            'production_extension_sha256':hashfile('vllm_rlt/_C.cpython-312-x86_64-linux-gnu.so'),
            'same_output':True,'complete':False}
(here/f'{args.phase}-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')
path = here/f'{args.phase}-raw.jsonl'
records = 0
complete = False
try:
    with path.open('w', buffering=1) as raw, torch.inference_mode():
        for dtype_name,h,rows,adds in groups():
            guard.check()
            dtype = getattr(torch, dtype_name)
            x = torch.randn(rows,h,device='cuda',dtype=dtype)
            if args.phase == 'extended':
                w = (1+.1*torch.randn(h,device='cuda')).to(dtype)
                residual = torch.randn_like(x) if adds[0] else None
            else:
                residual = torch.randn_like(x)
                w = (1+.1*torch.randn(h,device='cuda')).to(dtype)
            out = torch.empty_like(x)
            for add in adds:
                guard.check()
                res = residual if add else None
                def vllm_fn():
                    torch.ops.vllm_rms_review.rms_norm(out,x,w,1e-6)
                    if add:
                        torch.add(out,res,out=out)
                funcs = {name:(lambda name=name: getattr(torch.ops,f'rms_cache_{name}').run_out(out,x,w,1e-6,res))
                         for name in ('old','fixed','fma')}
                funcs['vllm'] = vllm_fn
                ref = rms_norm_reference(x,w,1e-6,res)
                native = rms_norm(x,w,1e-6,res)
                precision = {}
                for name,fn in funcs.items():
                    fn()
                    precision[name] = accuracy(out,ref,native,tol[dtype_name])
                    if name == 'fixed' and not torch.equal(out,native):
                        raise AssertionError(('fixed wrapper and production disagree',dtype_name,h,rows,add))
                record = {'dtype':dtype_name,'width':h,'rows':rows,'residual':add,'precision':precision,
                          'shared_output_mod16':out.data_ptr()%16}
                if args.phase != 'extended':
                    names = list(funcs)
                    rng.shuffle(names)
                    capture_order = names[:]
                    graphs = {}
                    for name in names:
                        fn = funcs[name]
                        for _ in range(10): fn()
                        torch.cuda.synchronize()
                        graph = torch.cuda.CUDAGraph()
                        with torch.cuda.graph(graph):
                            for _ in range(32): fn()
                        graphs[name] = graph
                    measured, orders = {name:[] for name in funcs}, []
                    for _ in range(7):
                        guard.check()
                        names = list(funcs)
                        rng.shuffle(names)
                        orders.append(names[:])
                        for name in names:
                            graph = graphs[name]
                            graph.replay()
                            start,end = torch.cuda.Event(enable_timing=True),torch.cuda.Event(enable_timing=True)
                            start.record()
                            for _ in range(50): graph.replay()
                            end.record()
                            end.synchronize()
                            measured[name].append(start.elapsed_time(end)*1000/(50*32))
                    record.update({'capture_order':capture_order, 'orders':orders,'graph_us':measured,
                                   'median_us':{name:statistics.median(v) for name,v in measured.items()}})
                    del graphs
                raw.write(json.dumps(record)+'\n')
                records += 1
                failures = {n:e for n,e in precision.items() if not e['assert_close_passed']}
                info = {'case':[dtype_name,h,rows,add], 'median_us':record.get('median_us'), 'failures':failures}
                print(json.dumps(info),flush=True)
                del ref,native,funcs
            del x,w,residual,out
        guard.finish()
        complete = True
finally:
    metadata.update({'complete':complete,'records':records,'finish_time_unix':time.time(),'external_processes':guard.foreign})
    (here/f'{args.phase}-metadata.json').write_text(json.dumps(metadata,indent=2)+'\n')

"""Derive compact, reproducible statistics from retained unprofiled raw rows."""
import collections
import csv
import hashlib
import json
import math
import statistics
from pathlib import Path

here = Path(__file__).resolve().parent
raw = {phase:[json.loads(line) for line in (here/f'{phase}-raw.jsonl').read_text().splitlines()]
       for phase in ('key','matrix','extended')}
assert [len(raw[x]) for x in ('key','matrix','extended')] == [54,444,342]
assert all(json.loads((here/f'{x}-metadata.json').read_text())['complete'] for x in raw)

def precision(rows):
    result = {}
    for arm in ('old','fixed','fma','vllm'):
        failures = []
        for row in rows:
            d = row['precision'][arm]
            if not d['assert_close_passed']:
                failures.append({'case':[row['dtype'],row['width'],row['rows'],row['residual']],
                                 'mismatched_elements':d['mismatched_elements'],'examples':d.get('examples',[])})
        result[arm] = {'passed_cases':len(rows)-len(failures),'total_cases':len(rows),'failures':failures}
    return result

def ratio(rows,num,den):
    values = [r['median_us'][num]/r['median_us'][den] for r in rows]
    return {'geomean':math.exp(sum(math.log(v) for v in values)/len(values)),
            'less_than_0.95':sum(v<0.95 for v in values),
            'between_0.95_and_1.05_inclusive':sum(0.95<=v<=1.05 for v in values),
            'greater_than_1.05':sum(v>1.05 for v in values),
            'min':min(values),'median':statistics.median(values),'max':max(values)}

def selected_cache(r, fixed):
    h,n,dtype = r['width'],r['rows'],r['dtype']
    e = 4 if dtype=='float32' else 8
    sm = 148
    t = 32 if h<=256 else (512 if n<sm and (h+256*e-1)//(256*e)>4 else 256)
    packs = ((h//e+t-1)//t if fixed else (h+t*e-1)//(t*e))
    k = 0 if n//sm>=2 and packs>2 else (1 if packs<=1 else (2 if packs<=2 else (4 if packs<=4 else 0)))
    return t,k

matrix = raw['matrix']
original = [r for r in matrix if r['width'] in (128,256,768,2048,2049,4096,8192)]
changed = [r for r in matrix if selected_cache(r,False)!=selected_cache(r,True)]
assert len(original)==420 and len(changed)==76
selected = []
for r in matrix:
    if r['dtype']=='float32' and (r['width'],r['rows']) in ((2049,8),(4096,1024),(8192,4),(8193,4)):
        selected.append({'case':[r['dtype'],r['width'],r['rows'],r['residual']],
                         'median_us':r['median_us'],'graph_us':r['graph_us'],
                         'old_policy':selected_cache(r,False),'fixed_policy':selected_cache(r,True)})

keys = ('Kernel Name','Block Size','Grid Size','launch__registers_per_thread',
        'launch__registers_per_thread_allocated','launch__occupancy_limit_registers',
        'launch__occupancy_limit_warps','sm__warps_active.avg.pct_of_peak_sustained_active',
        'l1tex__t_bytes_pipe_lsu_mem_global_op_ld.sum',
        'l1tex__t_bytes_pipe_lsu_mem_global_op_ld_lookup_hit.sum','lts__t_sectors_op_read.sum',
        'lts__t_sectors_op_read_lookup_hit.sum','dram__bytes_read.sum','smsp__inst_executed.sum',
        'smsp__inst_executed_pipe_fmaheavy.sum','smsp__inst_executed_pipe_fmalite.sum',
        'gpu__time_duration.sum','profiler__replayer_passes')
ncu = {}
for file in sorted(here.glob('ncu-*.csv')):
    rows = list(csv.reader(line for line in file.read_text().splitlines() if line.startswith('"')))
    assert len(rows) >= 3
    d = dict(zip(rows[0],rows[2]))
    ncu[file.name] = {k:d.get(k) for k in keys}
(here/'ncu-summary.json').write_text(json.dumps({'note':'One warmed kernel, replayed by NCU; cache-control and clock-control none. These timings are not benchmark results.',
                                               'captures':ncu},indent=2)+'\n')

sass = {}
for shape in ('unaligned_256_k4','unaligned_256_k2','unaligned_256_k0','aligned_256_k0','unaligned_512_k1','aligned_512_k4'):
    def instructions(name):
        source = (here/f'{name}-{shape}.sass.txt').read_text()
        return source[source.index('/*0000*/'):]
    sass[shape] = {}
    for prod,wrapper in (('production_old','old'),('production_fixed','fixed')):
        a,b = instructions(prod),instructions(wrapper)
        sass[shape][prod+'_vs_'+wrapper] = {'identical_instruction_text_and_encodings':a==b,
                                             'production_sha256':hashlib.sha256(a.encode()).hexdigest(),
                                             'wrapper_sha256':hashlib.sha256(b.encode()).hexdigest()}
(here/'sass-equality.json').write_text(json.dumps(sass,indent=2)+'\n')

monitor = {}
for path in sorted(here.glob('*-gpu-monitor.jsonl')):
    if path.name.startswith('prior-module-shadow-'):
        monitor[path.name] = {'discarded':'duplicate profiler import wrote the same log concurrently; retained for audit'}
        continue
    rows = [json.loads(l) for l in path.read_text().splitlines()]
    monitor[path.name] = {'samples':len(rows),'external':[row for row in rows if row.get('external')],
                          'before':any(row.get('tag')=='before' for row in rows),
                          'after':any(row.get('tag')=='after' for row in rows)}
summary = {'case_count':{k:len(v) for k,v in raw.items()},
           'original_420_precision':precision(original), 'matrix_precision':precision(matrix),
           'key_precision':precision(raw['key']), 'extended_precision':precision(raw['extended']),
           'comparison_of_medians_ratios':{'definition':'numerator latency / denominator latency; >1 means denominator is faster',
                                            'original_420_old_over_fixed':ratio(original,'old','fixed'),
                                            'matrix_444_old_over_fixed':ratio(matrix,'old','fixed'),
                                            'matrix_444_fixed_over_fma':ratio(matrix,'fixed','fma'),
                                            'original_420_vllm_over_fixed':ratio(original,'vllm','fixed'),
                                            'changed_cache_76_old_over_fixed':ratio(changed,'old','fixed'),
                                            'same_cache_368_old_over_fixed':ratio([r for r in matrix if r not in changed],'old','fixed')},
           'selected_cases':selected,
           'cache_policy_changed_cases':len(changed),
           'cache_policy_changed_by_dtype':dict(collections.Counter(r['dtype'] for r in changed)),
           'monitor':monitor}
(here/'summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps({'case_count':summary['case_count'],'ratios':summary['comparison_of_medians_ratios'],
                  'matrix_precision':summary['matrix_precision'],'extended_precision':summary['extended_precision']},indent=2))

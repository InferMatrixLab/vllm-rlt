"""Compare a shared-output wrapper with its actual production binary."""
import json
import sys
from pathlib import Path
from gpu_guard import Guard

guard = Guard(f'verify-{sys.argv[1]}')
import torch

here = Path(__file__).resolve().parent
which = sys.argv[1]
assert which in ('old', 'fixed')
production = (Path('artifacts/rmsnorm-cache-count-20261110/before.so') if which == 'old' else
              Path('vllm_rlt/_C.cpython-312-x86_64-linux-gnu.so'))
torch.ops.load_library(str(production.resolve()))
torch.ops.load_library(str((here / f'build-rms_cache_{which}/rms_cache_{which}.so').resolve()))
op = getattr(torch.ops, f'rms_cache_{which}').run_out
torch.manual_seed(7031)
torch.set_num_threads(1)
results = []
with torch.inference_mode():
    for dtype_name in ('float32', 'float16', 'bfloat16'):
        dtype = getattr(torch, dtype_name)
        for h in (2049, 4096, 4097, 8192, 8193):
            for shape in ((8, h), (4, 2, h), (2, 2, 2, h), (1024, h)):
                for layout in ('contiguous', 'offset_stride'):
                    if layout == 'contiguous':
                        x = torch.randn(shape, device='cuda', dtype=dtype)
                        r = torch.randn_like(x)
                        w = torch.randn(h, device='cuda', dtype=dtype)
                    else:
                        x = torch.randn((*shape[:-1], h+5), device='cuda', dtype=dtype)[..., 1:1+h]
                        r = torch.randn((*shape[:-1], h+7), device='cuda', dtype=dtype)[..., 3:3+h]
                        w = torch.randn(h+8, device='cuda', dtype=dtype)[2:2+h]
                    out = torch.empty(shape, device='cuda', dtype=dtype)
                    for add in (False, True):
                        res = r if add else None
                        prod = torch.ops.vllm_rlt.rms_norm(x,w,1e-6,res)
                        op(out,x,w,1e-6,res)
                        same = torch.equal(prod, out)
                        entry = {'dtype':dtype_name, 'shape':shape, 'layout':layout, 'residual':add,
                                 'input_stride':x.stride(), 'input_offset_mod16':x.data_ptr()%16,
                                 'weight_offset_mod16':w.data_ptr()%16, 'residual_offset_mod16':r.data_ptr()%16,
                                 'bitwise_equal':same}
                        results.append(entry)
                        if not same:
                            (here/f'verify-{which}.json').write_text(json.dumps({'cases':results,'complete':False},indent=2)+'\n')
                            raise AssertionError(entry)
                    guard.check()
guard.finish()
(here/f'verify-{which}.json').write_text(json.dumps({'cases':results,'complete':True},indent=2)+'\n')
print(which, len(results), 'cases bitwise equal', flush=True)

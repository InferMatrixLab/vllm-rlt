"""Record the exact tested runtime inputs and reusable artifacts."""
import hashlib
import json
import os
import platform
import subprocess
import sys
from pathlib import Path

here = Path(__file__).resolve().parent
def digest(p):
    return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def command(*args):
    return subprocess.check_output(args,text=True).strip()

files = {
    'production_source':'csrc/normalization/rms_norm.cu',
    'production_binary':'vllm_rlt/_C.cpython-312-x86_64-linux-gnu.so',
    'test_normalization':'tests/test_normalization.py','test_ouro':'tests/test_ouro.py',
    'test_activation':'tests/test_activation.py','test_native_build':'tests/test_native_build.py',
    'old_binary':'artifacts/rmsnorm-cache-count-20261110/before.so',
    'vllm_binary':'artifacts/rmsnorm-generic-20261109/vllm-source-build/build/vllm_rms_review.so',
}
local = ['CONTRACT.md','REPORT.md','fma.patch','variant-hashes.json','benchmark.py','gpu_guard.py',
         'verify_wrapper.py','make_variants.py','build_one.py','run_ncu.sh','ncu_target.py',
         'capture_traces.py','extract_sass.py','summarize.py','make_manifest.py','gpu-tests.log',
         'key-raw.jsonl','matrix-raw.jsonl','extended-raw.jsonl','key-metadata.json','matrix-metadata.json',
         'extended-metadata.json','verify-old.json','verify-fixed.json','summary.json','ncu-summary.json',
         'sass-summary.json','sass-equality.json','profile-ops-summary.json','profile-full-summary.json',
         'profile-ops.trace.json','profile-full.trace.json']
for name in ('rms_cache_old','rms_cache_fixed','rms_cache_fma'):
    local.extend([f'{name}.cu',f'{name}_source.cu',f'build-{name}/{name}.so'])
for file in sorted(here.glob('ncu-*.csv')):
    local.append(file.name)
hashes = {key:{'path':str(path),'sha256':digest(path)} for key,path in files.items()}
hashes.update({name:{'path':str((here/name).relative_to(Path.cwd())),'sha256':digest(here/name)} for name in local})
assert hashes['production_source']['sha256']=='b5e81d259f1d65c4e5abc9fb9b3ed9b8dc6c8130b84bbe842d62cf607d1d3260'
assert hashes['production_binary']['sha256']=='fac48ddb73f7f284e887b880ed0604d25362c9a3404adb280e368683c1ce09aa'
assert hashes['old_binary']['sha256']=='3c132ba489156b36876fdb971e68305583df76bf839ed2f8770ae828a0d5af04'
assert hashes['vllm_binary']['sha256']=='f71fed3f96c641f4c8188b3e088787a1ffa64bd6febe865ed9056b575eb0bd5e'
runtime_diff = command('git','diff','--','csrc','tests','vllm_rlt')
assert not runtime_diff, 'runtime/test source changed since tested snapshot'
assert command('git','rev-parse','HEAD')=='824cd3846316b5287f609ee5748b6433c1d802bb'

import torch
summary = json.loads((here/'summary.json').read_text())
monitors = {k:v for k,v in summary['monitor'].items() if not v.get('discarded')}
assert all(x['before'] and x['after'] and not x['external'] for x in monitors.values())
manifest = {
    'head':'824cd3846316b5287f609ee5748b6433c1d802bb',
    'old_commit':'50a7ce199ab37632249516f7112d82f02880aa48',
    'vllm_source_commit':'2b678ac739166bd0356883048673bbd1c34a3b0e',
    'tested_runtime_and_tests_diff':'empty before tests; checked empty again during manifest generation',
    'workspace_note':'The shared repository was clean at initial measurement; another agent later began documentation-only integration. This does not alter the locked runtime/test hashes.',
    'python':platform.python_version(),'python_executable':sys.executable,'torch':torch.__version__,
    'torch_cuda_runtime':torch.version.cuda,'driver':command('nvidia-smi','--query-gpu=driver_version','--format=csv,noheader','-i','7'),
    'nvcc':command('/usr/local/cuda/bin/nvcc','--version'),
    'gpu':'NVIDIA B300 SXM6 AC','physical_gpu_index':7,'logical_gpu_index':0,
    'gpu_uuid':'GPU-40e00845-d89c-1393-2c32-a2dca3ee9442','sm_count':148,'compute_capability':'10.3',
    'device_selection_note':'Physical GPU 3 became occupied before test start; all arms were newly measured on idle GPU 7.',
    'compiled_arches':['sm_80','sm_103'],'tested_arch':'sm_103','build_flags':'-O3; TORCH_CUDA_ARCH_LIST=8.0;10.3; MAX_JOBS=2',
    'test_suite':{'passed':384,'log':'gpu-tests.log','gpu_monitor':'process list checked before and immediately after; no continuous polling during the suite'},
    'timing':{'seed':42,'warmup':10,'repetitions':7,'graph_unroll':32,'replays':50,'unprofiled':True,
              'clock_locked':False,'output':'all four experimental arms share a single preallocated output; vLLM residual added separately'},
    'correctness':{'key':54,'matrix':444,'original_subset':420,'extended_seed3039':342,
                   'tolerances':{'float32':2e-6,'float16':2e-3,'bfloat16':1e-2},
                   'details':'summary.json; do not suppress recorded failures'},
    'guarded_stages':monitors,
    'trace_limit':'Full trace requested shapes, memory and stack; no allocation events with this preallocated-output window.',
    'discarded_captures':'First profiler script shadowed Python profile module and double-captured within one process; prior-module-shadow-* retained but excluded. Both modes recaptured with renamed script.',
    'preflight_failures':'PYTHONPATH omission and missing GPU- prefix normalization failed before timing; error logs retained.',
    'new_model_end_to_end_tests':False,'runtime_changes_or_commits':False,
    'sha256':hashes}
(here/'manifest.json').write_text(json.dumps(manifest,indent=2)+'\n')
print('manifest written with',len(hashes),'hashed inputs/results')

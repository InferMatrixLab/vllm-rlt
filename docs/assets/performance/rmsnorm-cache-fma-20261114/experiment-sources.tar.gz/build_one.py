"""Compile one variant without using a GPU; use the production CUDA flags."""
import os
import sys
from pathlib import Path
from torch.utils.cpp_extension import load

here = Path(__file__).resolve().parent
name = sys.argv[1]
assert name in ('rms_cache_old', 'rms_cache_fixed', 'rms_cache_fma')
os.environ['TORCH_CUDA_ARCH_LIST'] = '8.0;10.3'
build = here / f'build-{name}'
build.mkdir(exist_ok=True)
load(name=name, sources=[str(here / f'{name}.cu')], build_directory=str(build),
     extra_cuda_cflags=['-O3'], is_python_module=False, verbose=True)

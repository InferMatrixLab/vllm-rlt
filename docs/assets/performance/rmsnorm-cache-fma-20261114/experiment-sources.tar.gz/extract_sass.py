"""Save static resource usage and SASS for representative SM103 kernels."""
import json
import re
import subprocess
from pathlib import Path

here = Path(__file__).resolve().parent
libs = {'production_old':Path('artifacts/rmsnorm-cache-count-20261110/before.so'),
        'production_fixed':Path('vllm_rlt/_C.cpython-312-x86_64-linux-gnu.so')}
libs.update({n:here/f'build-rms_cache_{n}/rms_cache_{n}.so' for n in ('old','fixed','fma')})
shapes = {'unaligned_256_k4':r'rms_norm_kernelIfLi256ELb0ELb0ELi4E',
          'unaligned_256_k2':r'rms_norm_kernelIfLi256ELb0ELb0ELi2E',
          'unaligned_256_k0':r'rms_norm_kernelIfLi256ELb0ELb0ELi0E',
          'aligned_256_k0':r'rms_norm_kernelIfLi256ELb0ELb1ELi0E',
          'aligned_512_k4':r'rms_norm_kernelIfLi512ELb0ELb1ELi4E',
          'unaligned_512_k1':r'rms_norm_kernelIfLi512ELb0ELb0ELi1E'}
summary = {}
for name,lib in libs.items():
    res = subprocess.check_output(['/usr/local/cuda/bin/cuobjdump','--dump-resource-usage','--gpu-architecture','sm_103',str(lib)],text=True)
    (here/f'{name}-resource.txt').write_text(res)
    for shape,pattern in shapes.items():
        match = re.search(r'Function (\S*'+pattern+r'\S*):\n\s*(REG:[^\n]+)',res)
        if not match:
            raise RuntimeError((name,shape))
        symbol,resource = match.groups()
        sass = subprocess.check_output(['/usr/local/cuda/bin/cuobjdump','--dump-sass','--gpu-architecture','sm_103','--function',symbol,str(lib)],text=True)
        if 'Function :' not in sass:
            raise RuntimeError((name,shape,'no SASS'))
        (here/f'{name}-{shape}.sass.txt').write_text(sass)
        counts = {op:len(re.findall(r'\b'+op+r'(?:\.|\s)',sass)) for op in ('LDG','STG','FFMA','FMUL','FADD','FADD2','FMUL2','SHF','SHFL','BAR','LDS','STS','LDL','STL')}
        summary[f'{name}/{shape}'] = {'symbol':symbol,'resource':resource,'static_sass_counts':counts}
(here/'sass-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print(json.dumps(summary,indent=2))

"""Monitor this experiment's physical GPU and refuse to overlap other processes."""
import csv
import io
import json
import os
import subprocess
import threading
import time
from pathlib import Path

UUID = 'GPU-40e00845-d89c-1393-2c32-a2dca3ee9442'
HERE = Path(__file__).resolve().parent

class Guard:
    def __init__(self, phase):
        if os.environ.get('CUDA_VISIBLE_DEVICES') not in ('7', UUID):
            raise RuntimeError('Only physical GPU 7 is authorized in this run')
        self.phase, self.done, self.foreign = phase, threading.Event(), []
        self.file = (HERE / f'{phase}-gpu-monitor.jsonl').open('w', buffering=1)
        self.sample('before')
        self.check()
        self.thread = threading.Thread(target=self.watch, daemon=True)
        self.thread.start()

    def sample(self, tag):
        cmd = ['nvidia-smi', '--query-compute-apps=gpu_uuid,pid,process_name,used_memory', '--format=csv,noheader,nounits']
        text = subprocess.check_output(cmd, text=True)
        rows = [r for r in csv.reader(io.StringIO(text), skipinitialspace=True) if r and r[0].strip() == UUID]
        unexpected = [r for r in rows if int(r[1].strip()) != os.getpid()]
        self.file.write(json.dumps({'time':time.time(), 'tag':tag, 'gpu_processes':rows, 'external':unexpected}) + '\n')
        if unexpected:
            self.foreign.extend(unexpected)

    def watch(self):
        while not self.done.wait(1.0):
            try:
                self.sample('periodic')
            except Exception as exc:
                self.foreign.append(['monitor_error', repr(exc)])

    def check(self):
        if self.foreign:
            raise RuntimeError(f'GPU 7 external process or monitor failure; stopping: {self.foreign}')

    def finish(self):
        self.done.set()
        self.thread.join()
        self.sample('after')
        self.file.close()
        self.check()

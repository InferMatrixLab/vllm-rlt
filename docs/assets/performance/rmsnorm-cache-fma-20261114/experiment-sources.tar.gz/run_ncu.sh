#!/usr/bin/env bash
set -euo pipefail
export CUDA_VISIBLE_DEVICES=7 PYTHONPATH=.
ART=artifacts/rmsnorm-cache-fma-20261114
PY=/home/zjy/code/david/b_workspace/.b_rdma/bin/python
METRICS=launch__registers_per_thread,launch__occupancy_limit_registers,launch__occupancy_limit_warps,sm__warps_active.avg.pct_of_peak_sustained_active,l1tex__t_bytes_pipe_lsu_mem_global_op_ld.sum,l1tex__t_bytes_pipe_lsu_mem_global_op_ld_lookup_hit.sum,lts__t_sectors_op_read.sum,lts__t_sectors_op_read_lookup_hit.sum,dram__bytes_read.sum,smsp__inst_executed.sum,smsp__inst_executed_pipe_fmaheavy.sum,smsp__inst_executed_pipe_fmalite.sum,gpu__time_duration.sum
for args in 'fixed 4096 1024' 'fma 4096 1024' 'fixed 8192 4' 'fma 8192 4'; do
  read -r arm width rows <<< "$args"
  /usr/local/cuda/bin/ncu --metrics "$METRICS" --cache-control none --clock-control none \
    --kernel-name 'regex:rms_norm_kernel' --launch-skip 10 --launch-count 1 --page raw --csv \
    --log-file "$ART/ncu-$arm-$width-$rows.csv" "$PY" "$ART/ncu_target.py" "$arm" "$width" "$rows" \
    > "$ART/ncu-$arm-$width-$rows.log" 2>&1
done

"""Freeze and wrap the actual old/fixed kernels; only FMA changes body arithmetic."""
import difflib
import hashlib
import json
import subprocess
from pathlib import Path

here = Path(__file__).resolve().parent
old = subprocess.check_output(['git', 'show', '50a7ce199ab37632249516f7112d82f02880aa48:csrc/normalization/rms_norm.cu'], text=True)
fixed = Path('csrc/normalization/rms_norm.cu').read_text()
original = '    accum = add2(accum, mul2(f, f));'
replacement = '    accum.x = __fmaf_rn(f.x, f.x, accum.x);\n    accum.y = __fmaf_rn(f.y, f.y, accum.y);'
assert fixed.count(original) == 1
fma = fixed.replace(original, replacement)
sources = {'rms_cache_old': old, 'rms_cache_fixed': fixed, 'rms_cache_fma': fma}
digest = {}
for name, source in sources.items():
    (here / f'{name}_source.cu').write_text(source)
    body = source.replace('#include "../ops.h"', '#include <ATen/ATen.h>\n#include <torch/library.h>', 1)
    body = body.replace('namespace vllm_rlt {', f'namespace {name} {{', 1)
    signature = 'at::Tensor rms_norm_cuda(const at::Tensor& input, const at::Tensor& weight, double epsilon,\n                         const std::optional<at::Tensor>& residual) {'
    newsig = 'void run_out(at::Tensor out, const at::Tensor& input, const at::Tensor& weight, double epsilon,\n             const std::optional<at::Tensor>& residual) {'
    assert body.count(signature) == 1
    body = body.replace(signature, newsig, 1)
    alloc = '  auto out = at::empty(input.sizes(), input.options());\n  if (input.numel() == 0) return out;'
    assert body.count(alloc) == 1
    body = body.replace(alloc, '  TORCH_CHECK(out.is_cuda() && out.is_contiguous() && out.sizes() == input.sizes() && out.scalar_type() == input.scalar_type());\n  if (input.numel() == 0) return;', 1)
    assert body.count('  return out;') == 1
    body = body.replace('  return out;', '', 1)
    body += f'''\nTORCH_LIBRARY({name}, m) {{ m.def("run_out(Tensor(a!) out, Tensor input, Tensor weight, float epsilon, Tensor? residual) -> ()"); }}
TORCH_LIBRARY_IMPL({name}, CUDA, m) {{ m.impl("run_out", TORCH_FN({name}::run_out)); }}\n'''
    p = here / f'{name}.cu'
    p.write_text(body)
    digest[name] = {'source_sha256': hashlib.sha256(source.encode()).hexdigest(), 'wrapper_sha256': hashlib.sha256(body.encode()).hexdigest()}
(here / 'fma.patch').write_text(''.join(difflib.unified_diff(fixed.splitlines(True), fma.splitlines(True), fromfile='fixed', tofile='fma')))
(here / 'variant-hashes.json').write_text(json.dumps(digest, indent=2) + '\n')

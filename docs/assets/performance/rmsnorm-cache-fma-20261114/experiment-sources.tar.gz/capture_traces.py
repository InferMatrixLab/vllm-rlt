"""Capture one warmed representative op set in paired ops-only/full modes."""
import argparse
import json
from pathlib import Path
from gpu_guard import Guard, UUID

p = argparse.ArgumentParser()
p.add_argument('mode',choices=('ops','full'))
a = p.parse_args()
guard = Guard(f'profile-{a.mode}')
import torch
here = Path(__file__).resolve().parent
for arm in ('old','fixed','fma'):
    torch.ops.load_library(str((here/f'build-rms_cache_{arm}/rms_cache_{arm}.so').resolve()))
assert str(torch.cuda.get_device_properties(0).uuid).removeprefix('GPU-') == UUID.removeprefix('GPU-')
torch.set_num_threads(1)
torch.manual_seed(2912)
full = a.mode == 'full'
with torch.inference_mode():
    cases = []
    for width,rows in ((2049,8),(4096,1024),(8192,4)):
        x = torch.randn(rows,width,device='cuda')
        w = torch.randn(width,device='cuda')
        out = torch.empty_like(x)
        cases.append((width,rows,x,w,out))
        for arm in ('old','fixed','fma'):
            op = getattr(torch.ops,f'rms_cache_{arm}').run_out
            for _ in range(5): op(out,x,w,1e-6,None)
    torch.cuda.synchronize()
    with torch.profiler.profile(activities=[torch.profiler.ProfilerActivity.CPU,torch.profiler.ProfilerActivity.CUDA],
                                record_shapes=full,profile_memory=full,with_stack=full,with_flops=False) as prof:
        for width,rows,x,w,out in cases:
            for arm in ('old','fixed','fma'):
                with torch.profiler.record_function(f'{arm}-h{width}-rows{rows}'):
                    getattr(torch.ops,f'rms_cache_{arm}').run_out(out,x,w,1e-6,None)
                    torch.cuda.synchronize()
    torch.cuda.synchronize()
trace = here/f'profile-{a.mode}.trace.json'
prof.export_chrome_trace(str(trace))
events = json.loads(trace.read_text())['traceEvents']
kernels = [{'name':e.get('name'),'cat':e.get('cat'),'dur_us':e.get('dur')} for e in events
           if e.get('cat')=='kernel' and 'rms_norm_kernel' in e.get('name','')]
ops = [{'name':e.get('name'),'args':e.get('args')} for e in events
       if e.get('cat')=='cpu_op' and ('rms_cache_' in e.get('name',''))]
if len(kernels) != 9 or len(ops) < 9:
    raise RuntimeError((a.mode,'unexpected trace contents',len(kernels),len(ops)))
summary = {'mode':a.mode,'record_shapes':full,'profile_memory':full,'with_stack':full,
           'size_bytes':trace.stat().st_size,'kernels':kernels,'cpu_ops':ops,
           'note':'One eager profiled kernel per case; diagnostic dispatch evidence, not benchmark timing.'}
(here/f'profile-{a.mode}-summary.json').write_text(json.dumps(summary,indent=2)+'\n')
guard.finish()
print(a.mode,trace.stat().st_size,'bytes',len(kernels),'kernels',len(ops),'custom ops',flush=True)
